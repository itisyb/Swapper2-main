import React,{useState,useEffect} from "react";

const Navbar = (props) => {

  return (
    <nav class="bg-white shadow dark:bg-gray-800 px-40">
      <div class="container px-6 py-3 mx-auto md:flex md:justify-between md:items-center">
        <div class="flex items-center justify-between">
          <div>
            <a
              class="text-xl font-bold text-gray-800 dark:text-white md:text-2xl hover:text-gray-700 dark:hover:text-gray-300"
              href="#"
            >
              Swapper
            </a>
          </div>

          <div class="flex md:hidden">
            <button
              type="button"
              class="text-gray-500 dark:text-gray-200 hover:text-gray-600 dark:hover:text-gray-400 focus:outline-none focus:text-gray-600 dark:focus:text-gray-400"
              aria-label="toggle menu"
            >
              <svg viewBox="0 0 24 24" class="w-6 h-6 fill-current">
                <path
                  fill-rule="evenodd"
                  d="M4 5h16a1 1 0 0 1 0 2H4a1 1 0 1 1 0-2zm0 6h16a1 1 0 0 1 0 2H4a1 1 0 0 1 0-2zm0 6h16a1 1 0 0 1 0 2H4a1 1 0 0 1 0-2z"
                ></path>
              </svg>
            </button>
          </div>
        </div>
        <div class="items-center md:flex hidden md:block">
          <div class="flex flex-col md:flex-row md:mx-6">
            <button onClick={props.connectWalletPressed} class="flex items-center px-2 py-2 font-medium tracking-wide text-white capitalize transition-colors duration-200 transform bg-blue-600 rounded-md dark:bg-gray-800 hover:bg-blue-500 dark:hover:bg-gray-700 focus:outline-none focus:bg-blue-500 dark:focus:bg-gray-700">
              <span class="mx-1">{props.isConnected?"My Account":"Connect"}</span>

              <svg
                
                width="31"
                height="31"
                viewBox="0 0 31 31"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                xmlnsXlink="http://www.w3.org/1999/xlink"
              >
                <rect width="31" height="31" rx="15.5" fill="url(#pattern0)" />
                <defs>
                  <pattern
                    id="pattern0"
                    patternContentUnits="objectBoundingBox"
                    width="1"
                    height="1"
                  >
                    <use xlinkHref="#image0" transform="scale(0.00444444)" />
                  </pattern>
                  <image
                    id="image0"
                    width="225"
                    height="225"
                    xlinkHref="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAYAAAA+s9J6AAAgAElEQVR4Ae2dXcguV3XHn5tCoVflNCexpxBpEYptrP3QavyooqBpoRe5KKFJtbbSGoOmSU5OCEhIMCoSSpS2EqQmqdgGa4OYVNHUi7QiisfmwgQsIZIQT1DygZbQE6MXU35z3vWedfa755nZ8+y99p5518DDfDzz7I//Wv+9/rNmzzybzhdHwBGoisCmau1euSPgCHROQncCR6AyAk7Cygbw6h0BJ6H7gCNQGQEnYWUDePWOgJPQfcARqIyAk7CyAbx6R8BJ6D7gCFRGwElY2QBevSPgJHQfcAQqI+AkrGwAr94RcBK6DzgClRFwElY2gFfvCDgJ3QccgcoIOAkrG8CrdwSchO4DjkBlBJyElQ3g1TsCTkL3AUegMgJOwsoG8OodASeh+4AjUBkBJ2FlA3j1joCT0H3AEaiMgJOwsgG8ekegKgmfPvW4W8ARqI5AbT+sRsLnf/Rs947Npvvila/sfvr1uzr2fXEErBD42TNPdD/+8id6/8MPa/pfNRI+eO+d3dW/temufd3R7vY3b7onr9p0T3/y3d3pRx60soPXcwgRwL9+eNvbe3/D7/A//PDkA1+ohkY1En708jd3173mF7oTbzjaA8H6off+cvfUNWcI+dznbu5efPLhasB4xetBAD967p4be+LhX/gZ5OOD3133+z/f/f37LqvW4SokJPRf9bJNDwAgyOd9rznaff5PL+hOHT+yT8anbrqolw015UI163jFsxEQuYn/oLJ6n7rhWO9f+Jn4nKyJhrV8rAoJRYoKAHoNQB//o/O7U9df2D11w7EevO9ffVauPn/yvtmG8R+uHwH8Q+QmfnPqxLHejx699lh3y1vORj/tc2zXlKRVSKilaAgG+yITkA3PfOBYDyRgMpoxqiEpkBcuV9dPqik9FLkJ6XriHT+y7zMM5F//q5ecIz9jPldTkpqTkJD/npcelKIxYESeQsQ+KkLEvY9ER5GryA9fDg8CMbkpviHRD5+589Lzu5j8jPkbfllDkpqTcJsUjQEj8hQ5ERJRoqMQEhnicnXdRIzJTU0+IeCY/Iz5Wi1Jak7CMSkaA0cyWciKc+SpioxCSOQqpESuvvDYyXV75CHpHXbEntiVD5clIfFkX8vPmC9tO1ZLkpqSkFAfy4puA0Z/R1REXgB0NCoqUkp05DxuyrpcXRZj9+XmDcf2s5tCtNhafCJFfmrfku0aWVJTEn7j/s/0WSjp8Jw1UZEs16A8VUTsjXX8SD96EiFdrrZPxClyMyQhBJwjP2P+V0OSmpJwjhSNAQURiYqj8nQLIZ+9+/0uVxvhJHITe8ilxDa5GSPgf7zrJZOTLzF/0seYQGJ9496MhClZUQ3Ktu0UeRoaT253cD/S5ao9G0VuYhfIl0I8fpNLfsb8yzpLakbCHFI0BliyPN0SHXu5+s17q6Sp7WlgXyMD8fPfvPfAzfQDA2Roo2AfAnIPedvN95ivTD1mLUnNSJhLig4BCRmRJVuzp4ExDxh/7/qRpI7L1XwkFbk5Jbt5wCaBzSDgv//ZBdnkZ8yfrLOkJiTcNSsaAyp2bCd5Ghhb5CpGd7maTkjkJpPwwW+O3AzJSDkcY0ojdo7ZP+cxsvj4rcViQsJSUjQG+s7yNCTjiWP72dUffPiNvZyyMo6FA+SsQ+QmOO0nWSJ4hgQb24eAyE/sjX1jds99zFKSmpCwtBSNGYDRcmd5GjqQut3hzz6epS/P6IFHDrkZEpLLi9LyM+Y/llnS4iS0kqIxIEWeYliRM6GRZ+/ryeSfu/nQTQbYl5vXjM9imYOx2MtKfsb8x0qSFichTywT2mOdtDhWQp6GTiUPIq9drpaSmwfwrCA/Y75oJUmLk7CGFI0BSlRE1uyUPQ3labi/UrkqcnP/Om/L3M2QUKn7REAe7LZIvsT8RB+zypIWJWFNKarBlG0M2z8wXEKeRgiJ0/7vLb/Snb794sV+aD/Xeqk30+eQj9/UlJ/iJ3ptIUmLktAyK6qB27Yt2bUDDwyHJMq0T+Q9fet5i/0UVQ57GBP9mIKI3cQ+22xo+Z2FJC1KwlakaMxoJvJ0z8lOf+hYt9RPakRLPb8l+RnzE4ssaTEStiZFYwBbydNeki6QiLQ7lVRTz4d8PPnQmvyM+UlpSVqMhLWzojEwY8dE/pSUpzjcEiMh7Z5KqpTzKLdV+RnzkdKStBgJeRyE7FKsUy0eIyqSleMaqITzLZGEKcSaei7YtpL9nOqHpbOkTsLgvad99lRet5gpOYOD9gmaBUnS3AkZyJfrwdup5Ml13mJJ+KVPfaz7m9+ud5N+rgFKyVOccEnRMKcaoCzkJ9gKvnPtU+N3+DH+XGopFgm/+62vVZ0ps6uxSsjTpSRociVkIB+fXd/7sqstd/0914T4c6mlGAmXkB0dM45kTye/z2ZEvi5FkuaQopBvqfIz9IvFZkcZNcLOLHFfJFTy+2wGCLkESTo1yTJ0npafS7R5rM2loiDlFouEFH7Hde9cVIY0Br4cE3kqEmvIAceOty5Jd5Gigs3S5afYnDVJGfy45FKUhLxte4nJGW0EvU1UTHrdYiQati5JIdLYQBL7nt+tRX5qm+O/+HHJpSgJv/edb+/0sl8NRivbOeRpy5I0RrCxYxCQB6iXmPkc8yuuB/HjkktREq4hOTNkJOTp1LeBh07cajRMTcisUX6G9i6dlIHcRUlIBR+89FX7/8gbdnDp+3PlKc7bYjSkXeGAMbTPuSVfO9iCbzB5G/8tvRQn4advuXpV14Ux54CMqe+zaZGEQ4QLjxMxeUB6jfJT25frQfy39FKchEuZyK3Bn7OdKk9bk6RTpKhEyiU8+TDHhuFvSk/cFnIXJ+EakzOhsWQ/RZ62JknDaBfuHwb5KXaUtUVSBiIWJyGV0Bnp2GFYExWnyNNW7hmO3RuEgDVeO1jbV4iEFotJLWtOzgw5yhR52ookHZKih01+altaJWXMIuG//u1Nq0/OaAPKtshTsoji0KHMayFBE7aJfZGf9GXtCRixl16TlMFvLRaTSHhYkjPaiHp7mzytLUljUhQCLu3BW413jm2rpIxZJHz61OOH7rowdASI2D8wHLxuEYevGQ11hJbtw5L9DG2k98lj4LcWi0kkpCNrmkOqjZWyLbIufJ9NTRKKFIWAtIv+SDtT+ra2c/FXq8WsppZff2jtQERF/TbwWgkaSchAwMMuP7UPkJTBX60WMxIu9XUX2jg5t7U8rUVCyMeTD8hPj35n/3KNKFjydRYhuc1IeNiTMzECi+MjA2tI0iW9djCGX6ljlkkZCGlGQk/OnB1pQ+chKkKIFz9ik6ShHiYTUG/YFt8/2icRrZIypiSkMkYYN/Kw41uS0Ak4bAermTIiS80iIRUu7YXAVgMGhODZREsS+m2IOAlLv2NUiKfXpiT05MxBw0NAMpMkSSyvCz0jetAWDLrWSRnIaErCpb+LNHdkhID6LW6WJOT+IFlZvzY8l4xI0ZLvGNURULZNSbjm112kEFRnRYlIcsPcioR6qhpEJDsrbUrpxxrPtXidhZBP1uYkRHOv0XhT+4SzD72xzWoeqSahTNZe45vSptpEn4d/EiwsFzMSuhQ92t8SICFC9NMRUCJhLRIKEVn7jfujfRa/9BvWNMlNSMgjIYftwV49urItGVCZKibE0+uaJJR2MDis6eW9oR2m7uOvVrNmipMQAr77vMN9fxACtvSk/baBADLy/WF8kj4kKH771c/eoYNWke3iJKTVjCiHNRJyDRg+NSFRJ1zj/BbJmTESChHJ3B7WhA3+WvrN28JoExJSGRqbezCHJTGzLQETkk/2WyIhbUKakrAhQhwWMoqPrnbaGlknHhFZ+/Q1HJYEhziykGxs3RoJ99t//YV9RnftRMQvmdVlvZhFQt2xNb9zRhIwQxnQbURskYRCRPqz5qluNWbKCCfMSUiY/8DbXrbKe4UQUD+su41wse9wdItrQuqJ1T92jEFizQ//4peWMrQKCXmmkAtenlwOM1FL34eAegramEPHvm+dhLQZIq51qht+iX/ip5aLWSTknf5rzJDKdRIJjLkRRgi5BBLSVtop76NZ+uAZaz9+avEfFEJ0ExIS4tcYASEgU9BOXX/hzgQU525ZjspgIW1d61Q3iYhW0tSEhDCezCijzlpuUSA/t01B0w6bsm1BwpT2bDtXIv+aEjbin5bzR81IKETklfhkomIyYCnHICAJCq6PtjnpnO+WRELpH2Rcw1Q3/BL/tCQgvDAloWhg7hUulYgQcMoUNHHQ1PUSSUgfGZCWPNUNf7R8zaFwoRoJqfiO6965OGnKNSAJCZFhqQSbcv5SSShEXOJUNyQo/lhrqRIJ6SzT2FqfOQPpiHx8hp4BnEKslHNKP0kRPkuY0rYp5zJAyVQ3wU4yyK1ebuCHlo8uhWSvQsKWJ3QL8XAYrnOIfMhPHLBkBBQHXzoJ93G6/sIeNyIjOIInpGyVkGTvrR5dqkpCLng/9CevbSoCCukk2pFwYSRHFvL2Mz4W5FsTCaUv4CYYgie4gq8mZEukJCLin6tPzDBBtnZSRojHmvS6zHTpPnrmtYP61YMlMqDipLH1GiKh7hf4yXWuEBKcOY7CAH9tj5qSFb88NBO4maNnPXVNDI2RGY2RmTraiaPodenrJ+2ssq2dVrcl13aNPsUGFiEka77HHjVlK8kZ/LLGUuWakHBPp0sSUUiHzGS0ZdTV8khHuyEHF2JYrkuTkPIt+0Nd4D6EsRzXpOR8bnfIJIDS15L4If5oLUOF8FVISOVko3LPJRXiEe0kqcIoqw0sRh9b13BWHHaNJEztl7YX9pPkjtiXdU7Zih9aTVET4ul1NRLSCHmqYi6gYhRJqjB6cvGvjThGttj3GN46Wkh9ayUh/QPXGN5jx8SenCfJHW4ZYfddoyQEtH7ZryYg21VJSANSb1cI8VjrpIoYivWYUce+F0LUWK+ZhFNk6ZhttJ3Biig5N7kDAa3eIxMST+9XJyGN4bGRoYwpZBPiSVIlvIUwZriU7zFsDfJJnTkcdVt/KV/qqrHOPcgIKYmy+MXU5A63I3jDQwtLEyQECD2fVEgn0W5OUmWbIw59V1OGCiHWTkL6OVeWDtlNjgshWYOj3AIJZWutWxFDhG+GhDSQFDHE2zWpIkZJXQsRaq4PAwlL9xG7a0JCerkFgn/xpERLS1MkfPHJh7v/+8BmH8BUEu1yfm0Zqom/Sz/GfgsBdF21tnPL0rF+Cynxr5qZ0Bj5myLhT79+V0/CMUBzf9+CDNVkyN0/XZ6up/Z2KVmq+xtuQ8LnT94X40K1Y02R8IU7LulO33reztnNEPix/drOGNY/1t5dvg/rqrlvIUsPYHXred1P7r6iGuFiFTdDwp8980SVKNiSDBVCHHCcD+1+20XKlDpaWVvLUnAgGra0NNOa5795rzkJW5OhQgwhTIm11NHS2lqWtiZJmyHhT+66zFyKIoemfiydtqRTWvZjKrbmsrQxSdoMCRmdSoz8Q2Vi+P9+19Hukb++4JzP/1x1QRf78FrD6OfEmWxjisOF54bEKEXCWOQP25Kyv9/uAWxiOHIsxBw7UO+QrUocb0mSNkHCGlIUw+IMOECJT+ho7A85Jcc1wYuSMCDMUJti7S+BE2VSVwmibSuzH/QfebCJS8MmSEi2qkZWlKQATljKueaWe+r4kSJOSX/ntqnU78C/RnIGf3vx365zEgoC1lJUj5BEoNaIWMopWyMhuIO/tofldiuStHokPP3Ig+ZZUW1oHBNHQBKVGu1Tyz0MJARvcC/VV23joe1WJGl1EiIJakhRbRicoSUilnJMym1hsBECgrm2g/l2I5K0OglrSlExOs7ZChFx0FKZwhZIqAlYarARu05a33qeXBVVW1clYW0pqo0kJKwdEblOKkVCyq15/asJWD0K7s1CIgi88NjJagSk4qokbEGKChF1NKxJxH4wOHHmURxpW461PGNH+anXqDnODwnYRBTcm8JWO0talYS1rwVD5+4JoO6j4Tg5HDClDCFh2LYc+/3N9QokDAlIH3P0J0sZPDBQWZJWIyESoIXrQW3IMBriLLmIOLUcGQh0u3JtS9lTBoWp7R0rK0bAVqKg4FpbklYj4Ytfua05EmIUcVS93sUh5be8NeDXfu9t3T9e+vJBYmuHFQfJuZY+SZtiBPr8Zb/at5Onz/l+27mx3+tjuj9SN+ucfcpRFiTEH2st1UjYg1fh2cExo8WiIY6T6oyc/1/veEl34yWv6javuKT/QMLffd1bB8uSm9elHFWIMJScoc1/+Po/6Ekobab99GNO/6U+vS41JW/Mrlu/3/PDQ0VCeY3FVmAyPkOXWo92Gr09xRE5h/efvuetr90nHuSTD85NtNERQ7Zrk5B20T5pq6w5Rn/4+4CpGGjc9HaqLazO76Phkw9X4WGVSNiqFBWD908bqASNdqKYE3KMD0582ZveEHVkcWjWl7z+Td1DV2wOEFHXkztihH0S4sua9tN23c5wGzISKemn9Fl+L2uO637o7dx9EnvlWNeUpFVI2IPWoBTVxtTOE27jaNrpuM6DWLEoEjoy+5wXi4a6ntwOO0bCoSg41H5kdXh9u42A9E3j29x2RUlqTsJar7FINXrotJogfar/+JGeSBBq85tnr/liThs7RtQJyazrKE3CsO6xKBj2QfcbMvLkB5MBdB/0du7+pNpzyvm1JKk5CVuXotpY2on0Ns4mr9AjkfPFK1/ZXzPhqL1zRq6rYk7MtaOOqLqO3E4bDiqahCReaHfYxnBf941rRPpN/wWLQRKesH1gV9swZbuWJDUn4enbL64+YXuqYULH3SeJmtEiDsgfX1Iu/43Av70i18YiJI4sZNBJGeopTULJkFI/7QgJJ/sS8egP/eKt1vQz9oeqQyTM3Zep9ks+D0l6+8XmyRlTEi5Fimrj7RMvSNToc/Q2pMRB+Tx100Xdp//id/aTNWG0YZ8oRDQM68ntuLEBhXpjUVAiHhKV9tMP6RP90/3V2zIj55y+LCQKSj+Ihvip5WJKwlov9xWA56xjzouTTSlLE1Jkq75viLNLNDzHcQ0iIfURBcP2sC8ycwrxNA5hH9jPPZjo+kpsQ0L81HIxJeGSpKg2cGyE3xYR9G/1tiZl/5del7+6l61Eo9CBcztvbDChXmTmxy9/dS+jNenm9C/sA/JU938R2xUkqRkJlyhFxWliDizfzV0LIVlTfng9VZqE1Ecduh1z+yK/C0mYuw9ST+m1tSQ1I+ESpag2dhgN9Xc5tsPpcrkdmPI0SagvR7t1Gbr8RUZB9YyhpSQ1I2Gt/5nQTrLLdujEu5QV+21YfmkS5i6fPmkSlig/hluRY7ee1+GvVosJCZ//0bNNPjGRakAtGVN/O+X8kk4cknxKe1LPkfYvOQpKny0lqQ0JK/zPhICZc60dOWe5UpY4MevckUS3nfKlzpxraX/OMmuVZZklNSFhjf+ZKGU8iYa5yydBImWXJmGpSEW7S5WdG+/R8gwlqQkJGVVGO13x0aWUtklESfnN1HN1cqZkJCyRlCmJy1T8cp+H33IpVXopTkL+FXVNJMTQjPa5SUK54silI2Gptq8mCqosKf+TUnopTsJa/zORe1TU5eHEJRyZOuS6Knf5lCdl677k2i6JSa42JpfDX6jddVlpDpZ/5eHaomCyIRNlthClJAm5/izdj7WUbyFJi0bCll7uK06BA+b6SJk510i6knK0lGTMhWlrA0RPwsKStCgJmar25FWbrp9tsvdnmubbI+/ZZBLzlA+P/oSfnOSTsiQ5UyoSlkjK0PYQG/an4CrPUw6te2VQy3dOHOv9l3cilVyKkpCG8xgMT12bk0/9gy4OMWTkXY6XiCpy7VaKhCXKBYddcBz6LXbrlUFFElJ/6aU4CZ/73M3d96+uGw0BklF5yNhzjlOeOEhuxy4pRyXi5lj3A8aJM9nikvjWGsAJHs/dc2NpDpZPzPCm7eqSlJF0RJamElGTECfJKfOWQMJeNiu1kZuEtWUoNsVvyWuUXopHQjpQOxICKFErpyyNSSXqyBFhaG/u6Ep5udonCoB2WmErdVmuIaHFYlLL0598d9XrQjEczpNrxI6RUOrZlUBEmV3LCAcDyts1WlOG9FGvwTXnABeSXNdltn38SPfD295uwcHycpReMGumhWjYGzCTLB2TS7s4PM5egoS7lKnlZ5QIRrhG6y6QuMFfLWbLwA+TSMj8uyauCzPK0jES4ixziViKhGF0nLo/KTJlIOE2dWFFPqkHf7V64ZMJCWH7Dz78xiYkKSDnkKVirLE1dU11dn3eLlFLlyPbc8rjN2P909+nJrf0+WGiS5drvs2LjHnDnNFiRsIff/kT7UjSDNnSSdFByaRUEqSeL2TLtU4lIHhoUqVuT1EWVmREinJrzWoxIyGzDlqRpBgTp9klmZBKQuqcK09zEWtqOaPXf2pwEWLsQsKWZCj9wU8t/8fejISMKs0kZ/acCMeZky3dRTpR51Qy1DhvzuAig5o1ljIA5F5DQsvFtLZn735/M9eF+4abkVDIMXKPyc3cE5nHykuVn/v4qQFtjrJoSYb2fTp+pOOWmuViSkJmH7QkSQGdkT/VeXKQkLpj8lTIQrvYzvV59NozEVjK11F2jvzMQcJcOIZt2WW/vzVx8j5LDtrcopAecauiNUmKwXD4lERCTufRROQN2JDlopce7X7xl472a7ZzfCjvLb9xft9X6hESzpWfoaOnDma7SPqw7pz7BAmLV1oIJ1ibRkIqZBZCzacqBg2WIEuzS6jjR/o/XLnz0vO7zeYMASFNzs/Ro2fKo3zq4Tm57HaoiWEkWTRo66FzDWfJVCVhc7cqZlzTJBt3i9GfumbTPfEPf9k9+sA/d5vNpoMspT/UQ33US/05yThFUeRUEtlsceJYr9LwT+vFPBI28aDvACmQVFMyfLsavpfkx4/0JPjuf97f8Xnw3jtNSUh9Ujdk7ImY4bnPMRK2KkOxKVK09AO8MYKbk5BG9NchGQy+Kxmiv58gqeZeRwn5eEZNCCDrf/r4R0xJ+KVPfexAG4SMc6/bwWWMhNml/MCAGrXt2LlcFlRYqpCwhQd9h4yEIyGXhpxpzkiOU1Mu/RbShetbb3ifKQkhfdgG2WeQIDKmkpE+blMSrcrQ3heMHuCNcbwKCZt50HdgZNw2oqeQsL/eOnGse+xfPjjo8OL4N1373m6z+bni14Ncb1IPpJe6h9YMGmAh/RgauOT4GAn5Xs5tbY0UtXiAtxkS0pCphq1mrAFZOmU07/t2/YWTyCcE+PPLLjWNhNQndY+tGUSww5jNINmQimhahu4lZWIEsThWJRLSsVYe9B0i+ZBDbSMhTsrs+ymRL3T8P37bW/pbEqUzo5TPrQ/qC9swtk+/6N8QGedgNoS/6fFKtyaE4NVIyAOTqdccpoYZuIl/YETnsZcdyCeO/4qX/7opCalP6k5dn0PGMMEWURAty1B8Cj+0eoBXiKfX1UjY8q2Kc8geONU+CffIx3OSj37+72Y7tBDA6h6hRFquC6XuuesoGYfwGrj+PgfrSudwPWj1AK8mn2xXIyENaOlB3yFnCCUWWUMiXy7yQYBv3P8Zs+vBsyTc9PXOJaD+HYMQePQy9fiR/czyNuk+hLf5ceMHeIV4el2VhK3OngkdASJyy+KhKzb9tLsckU87Mffs7CPhpovdK9TtSt0GF6YlghN4tS5DsTNS1PIBXk0+2a5KwtYe9A3J1+/v3S9Dsnzttit3lnAxx7a8Ua8j4bZ7hbF2Tj0GTuDVX/OH14yVJGfUthUe4BXi6XVVEtKQnPMWh4BOPq6IRzaQkZJ7SE+feryfXoZ8nOqQU86zvFF/loTT7hVOab+cAy5MhwMn8OrvM950UdOERELXXqq3oIkHfRXpGBS4fUK2bOhiHWf76mfvyHZNJTfqSZbYfTZdyr1CIVpsrfGIOTQ4gqfclmomSh4/0uF/tZfqJKzyTlJFOhyC6xiuT1Mm7373W1/ricjIrydDx5x07JjcqIeMRMXSnzOk38y6V6j7In1nQAKPqQs4gze4g38tUva3Jowf4I1hVJ+EVu8kVcTTEjMGytRj3/vOt88hIk45R6py45zrM35r9aG+OfcKaZ+QjzUEBIddllrSFfJbP8Abw6k6CWlUkQd9FekAe0xixsCZcozrHxxRO2YqGcPfWu7ryLZtOyQfbaTf9D/noqVr0ShZeZaMxqwJEua6VYG8EGkzR2JqYFK2GU1x0rlkjDm4FRG3EY/vYm2jnxy3iCJauop9cyTzKAu/a2FpgoSMfpBnpywmjwrdc2OflbNwjpjxwutETSScdsjhY46uf1tqe06bIGDK9V8Mp7nHsGsvXfcetZIBdw4p+e1Q4m1u++b+rgkS0vhJQCqJSWq5lMScCya/k9sYQ8SJOX5LJBxrS275uQvWWrriD0mkrPQAb6y/zZCQe0pIhAPR8PiRHlwAZmpUahYz1mmLYycf+EJUngo5NRnHHF9+k3s9tQ1EP/rT+iLSFT/ZRkj8rPYsGY1lMyREZgAcEVG0P9OeaktMDVbqdix7GhIJItQk4VjdELCl6DfVBlq64kealGzjb60szZAQQCBfixJzF2PhDDg6zhwSsOV9iX61rq93wTz2Wy1d8bOWlrZa0xIymdsyJSq2QkoIuOu9v8zwrbo4J6GheYkqEK3VqEi7iNpriX6Gpt2pKifhTvDN+/G2Wxm1oiEErHXrYR6K6/mVk7CSLcduZViT0aNfJUeo8V8U9braZs1jtzJKktGjXxs+4ZGwATsQFSGE5QdyL/HWQwPmyt4EJ2F2SOcViByEFFafea30X5VAwElYAlUv0xFIQMBJmACWn+oIlEDASVgCVS/TEUhAwEmYAJaf6giUQMBJWAJVL9MRSEDASZgAlp/qCJRAwElYAlUv0xFIQMBJmACWn+oIlEDASVgCVS/TEUhAwEmYAJaf6giUQMBJWOo7fssAAADgSURBVAJVL9MRSEDASZgAlp/qCJRAwElYAlUv0xFIQMBJmACWn+oIlEDASVgCVS/TEUhAwEmYAJaf6giUQMBJWAJVL9MRSEDASZgAlp/qCJRAwElYAlUv0xFIQMBJmACWn+oIlEDASVgCVS/TEUhAwEmYAJaf6giUQMBJWAJVL9MRSEDASZgAlp/qCJRAwElYAlUv0xFIQMBJmACWn+oIlEDASVgCVS/TEUhAwEmYAJaf6giUQMBJWAJVL9MRSEDASZgAlp/qCJRAwElYAlUv0xFIQMBJmACWn+oIlEDg/wGSCs4jBYU4owAAAABJRU5ErkJggg=="
                  />
                </defs>
              </svg>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
