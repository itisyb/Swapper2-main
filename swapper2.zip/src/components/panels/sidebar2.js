import React from 'react'

const sidebar2 = () => {
    return (
        <>
          <div className="md:-ml-40">
            <div class="max-w-sm h-full mx-auto overflow-hidden bg-white rounded-lg shadow-lg dark:bg-gray-800">
              <div className="mt-20 text-center mx-10 my-5 rounded-2xl">
                <div>
                  <form className=" border-0 ">
                    <fieldset>
                      <legend className="text-left font-bold">From</legend>

                      <div class="w-full h-full border-0">
                        <input
                          placeholder="Select from"
                          list="to-list"
                          className="w-full outline-none border-0"
                          type="text"
                        />
                        <datalist id="to-list">
                          <option value="A" />
                          <option value="B" />
                          <option value="C" />
                        </datalist>
                      </div>
                    </fieldset>
                  </form>
                </div>
              </div>
              <div className="text-center mx-10 my-5 rounded-2xl">
                <form>
                  <fieldset>
                    <legend className="text-left font-bold">To</legend>

                    <div class="w-full h-full border-0">
                      <input
                        placeholder="Select to"
                        list="to-list"
                        className="w-full outline-none border-0"
                        type="text"
                      />
                      <datalist id="to-list">
                        <option value="A" />
                        <option value="B" />
                        <option value="C" />
                      </datalist>
                    </div>
                  </fieldset>
                </form>
              </div>
              <div className="text-center mx-10 my-5 rounded-2xl">
                <form>
                  <fieldset>
                    <legend className="text-left font-bold">Amount</legend>

                    <div class="w-full h-full border-0 flex">
                      <input
                        className="w-full outline-none border-0 flex-shrink"
                        type="text"
                      />
                      <button class="flex items-center  font-medium tracking-wide text-white capitalize transition-colors duration-200 transform bg-blue-600 rounded-md dark:bg-gray-800 hover:bg-blue-500 dark:hover:bg-gray-700 focus:outline-none focus:bg-blue-500 dark:focus:bg-gray-700">
                        My Account
                      </button>
                    </div>
                  </fieldset>
                </form>
              </div>
              <span className="md:mx-10 mx-5 md:ml-20 text-sm">
                Estimated time for completion: 6cycles
              </span>
            </div>
          </div>            
        </>
    )
}

export default sidebar2
