import React,{useState,useEffect} from 'react'

const Sidebar = (props) => {
  const Datetime = new Date();
  
  const [selectorone, setselectorone] = useState(false)
  const [selectortwo, setselectortwo] = useState(false)

  const get_date = (date) => {
    var yyyy = date.getFullYear().toString();
    var mm = (date.getMonth() + 1).toString();
    var dd = date.getDate().toString();
    var mmChars = mm.split("");
    var ddChars = dd.split("");
    return (
      yyyy +
      "-" +
      (mmChars[1] ? mm : "0" + mmChars[0]) +
      "-" +
      (ddChars[1] ? dd : "0" + ddChars[0])
    );
  };

    return (
        <>
          <div className="md:ml-40">
            <div class="w-full max-w-sm px-4 py-3 mx-auto bg-white mb-2 rounded-md shadow-xl dark:bg-gray-800">
              <div class="flex items-center justify-between">
                <span class="text-sm font-bold text-gray-800 dark:text-gray-400 mx-3">
                  Total Balance
                </span>
                <span onClick={()=>{setselectorone(!selectorone)}} class="px-3 py-1 text-xs text-indigo-800 uppercase bg-indigo-200 rounded-full dark:bg-indigo-300 dark:text-indigo-900">
                  <span className={selectorone?"text-white":""}>USD</span> |<span className={!selectorone?"text-white":""}> ETH</span>
                </span>
              </div>
              <span class="text-sm font-light text-gray-800 dark:text-gray-400 mx-3 pt-4">
                Today {get_date(Datetime)}
              </span>
              <div class="flex text-center mb-5 mx-5 text-2xl">
                <svg
                  id="Layer_1"
                  version="1.1"
                  viewBox="0 0 32 32"
                  width="32px"
                  className=""
                  xmlns="http://www.w3.org/2000/svg"
                  xmlnsXlink="http://www.w3.org/1999/xlink"
                >
                  <path d="M4,10h24c1.104,0,2-0.896,2-2s-0.896-2-2-2H4C2.896,6,2,6.896,2,8S2.896,10,4,10z M28,14H4c-1.104,0-2,0.896-2,2  s0.896,2,2,2h24c1.104,0,2-0.896,2-2S29.104,14,28,14z M28,22H4c-1.104,0-2,0.896-2,2s0.896,2,2,2h24c1.104,0,2-0.896,2-2  S29.104,22,28,22z" />
                </svg>
                {
                  !selectorone && 
                <p class="mt-4 text-gray-600 dark:text-gray-300 ml-5  ">
                  {props.balance !== undefined ?props.balance+" Eth":"Please Connect Wallet"}
                </p>
                }
                {
                  selectorone && 
                <p class="mt-4 text-gray-600 dark:text-gray-300 ml-5  ">
                  {props.balance !== undefined ?props.balance*100+"$":"Please Connect Wallet"}
                </p>
                }
              </div>
            </div>
            <div class="w-full max-w-sm px-4 py-3 mx-auto bg-white rounded-md shadow-md dark:bg-gray-800">
              <div class="flex items-center justify-between">
                <span class="text-sm font-bold text-gray-800 dark:text-gray-400 mx-3">
                  Other Balance
                </span>
                <span onClick={()=>{setselectortwo(!selectortwo)}} class="px-3 py-1 text-xs text-indigo-800 uppercase bg-indigo-200 rounded-full dark:bg-indigo-300 dark:text-indigo-900">
                  <span className={selectortwo?"text-white":""}>USD</span> |<span className={!selectortwo?"text-white":""}> ETH</span>
                </span>
              </div>
              <span class="text-sm font-light text-gray-800 dark:text-gray-400 mx-3 pt-4">
                Today {get_date(Datetime)}
              </span>
              <div></div>

              <div>
                <div class="flex flex-col mx-5 mt-5 text-gray-700 dark:text-gray-200">
                  <div className="my-2">
                    <span className=" text-md font-bold "> Mainnet</span>
                    <div className=" text-sm">
                      {" "}
                      20.00232{" "}
                      <span className="text-blue-400">(51.4 pending)</span>{" "}
                    </div>
                  </div>
                  <div className="my-2">
                    <span className=" text-md font-bold "> Mainnet</span>
                    <div className=" text-sm">
                      {" "}
                      20.00232{" "}
                      <span className="text-blue-400">(51.4 pending)</span>{" "}
                    </div>
                  </div>
                  <div className="my-2">
                    <span className=" text-md font-bold "> Mainnet</span>
                    <div className=" text-sm">
                      {" "}
                      20.00232{" "}
                      <span className="text-blue-400">(51.4 pending)</span>{" "}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>      
        </>
    )
}

export default Sidebar
