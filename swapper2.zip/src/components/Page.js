import React,{useState,useEffect} from "react";
import Sidebar from './panels/sidebar'
import Sidebar2 from './panels/sidebar2'
import Tables from './panels/Tables'
const Page = (props) => {

  return (
    <>
      <div className="">
        <div className="grid md:grid-cols-2 grid-col-1 mt-20">
            <Sidebar
            balance={props.balance}
            />

            <Sidebar2/>
        </div>
        <div className="my-20 w-full ">
            <div className="pl-40">
                <span className="font-bold text-2xl">Transaction</span>
            </div>
            <div className="mx-20 ">
            <Tables/>
            </div>
        </div>
      </div>
    </>
  );
};

export default Page;
